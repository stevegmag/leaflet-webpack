## 0.1.0

* Multi-point support
* nearestLayer
